{ TABLE "informix".nf_obs_livro row size = 132 number of columns = 5 index size
=
             30 }
create table "informix".nf_obs_livro
 (
   cod_empresa char(2) not null ,
   num_nff decimal(6,0) not null ,
   ser_nff char(2) not null ,
   texto char(120),
   dat_emissao date
 );

revoke all on "informix".nf_obs_livro from "public" as "informix";


create unique index "informix".ix1_nf_obs_livro on "informix".nf_obs_livro
   (cod_empresa,num_nff,ser_nff,dat_emissao) using btree ;
create unique index "informix".ix_nfobsliv_1 on "informix".nf_obs_livro
   (cod_empresa,num_nff,ser_nff) using btree ;
